<p>Hi Sir/Ma'am</p>

<p>A reset password request made on the portal against your account, if you not request you can ignore this email.</p>
<p>To reset your password, please click below link</p>
<a href="{{$data['url']}}" target="_blank" style="padding: 10px 20px; background-color: #007bff; color: #fff; text-decoration: none;">Reset Password</a>

<p>This is an automated email, please do not reply.</p>