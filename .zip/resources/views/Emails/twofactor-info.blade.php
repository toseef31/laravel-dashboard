<p>Hi Sir/Ma'am</p>

<p>{{$data['message']}}</p>

<p>This is an automated email, please do not reply.</p>