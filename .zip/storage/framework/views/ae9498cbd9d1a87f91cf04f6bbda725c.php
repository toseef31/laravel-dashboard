<p>Hi Sir/Ma'am</p>

<p><?php echo e($data['message']); ?></p>

<p>This is an automated email, please do not reply.</p><?php /**PATH D:\laragon\www\JohnRaeCollectionPanel\resources\views/Emails/twofactor-info.blade.php ENDPATH**/ ?>