<p>Hi Sir/Ma'am</p>

<p>Two factor authentication has been enabled for your account. Your secret codes are:</p>
<ul>
<?php $__currentLoopData = $data['codes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($code); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>

<p>This is an automated email, please do not reply.</p><?php /**PATH D:\laragon\www\JohnRaeCollectionPanel\resources\views/Emails/secret-codes-twofactor-enabled.blade.php ENDPATH**/ ?>